============
Installation
============

At the command line::

    pip install final-project
