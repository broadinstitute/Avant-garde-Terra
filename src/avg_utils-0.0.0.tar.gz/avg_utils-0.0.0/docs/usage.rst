=====
Usage
=====

To use final-project in a project::

	import final_project
