
Changelog
=========

0.0.0 (2019-05-04)
------------------

* First release on PyPI.
