
from final_project.cli import main


def test_main():
    main([])
